package com.fileUploadToGoogleDrive;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import com.google.api.client.http.FileContent;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.DriveScopes;


@WebServlet("/UploadDownloadFileServlet")
public class UploadDownloadFileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private ServletFileUpload uploader = null;
    
	String CLIENT_ID="119002672620-iec38m67i467j8ij5vtfal5f8d6baeaa.apps.googleusercontent.com";
	String APPLICATION_NAME="Web client 1";
	String redirect_uri="http://localhost:8080/fileUploadToGoogleDrive/UploadDownloadFileServlet";
	
	String client_secret="6eFzH5SRPAkwtALHRKg5v_t1";
	
	List<FileItem> fileItemsList;
	@Override
	public void init() throws ServletException{
		DiskFileItemFactory fileFactory = new DiskFileItemFactory();
		File filesDir = (File) getServletContext().getAttribute("FILES_DIR_FILE");
		fileFactory.setRepository(filesDir);
		this.uploader = new ServletFileUpload(fileFactory);
		
	
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String code=request.getParameter("code");
		String state=request.getParameter("state");
		String authuser=request.getParameter("authuser");
		String session_state=request.getParameter("session_state");
		String prompt=request.getParameter("prompt");
		 
		/*System.out.println("code = "+code+",state = "+state+",authuser = "+
		authuser+",session_state = "+session_state+",prompt = "+prompt);*/
		
		if (!request.getParameter("state").equals(
			      request.getSession().getAttribute("state"))) {
			 
			   System.out.println("Invalid state parameter.");
			  }
		if (request.getParameter("state").equals(
			      request.getSession().getAttribute("state"))) {
			 
			   System.out.println("valid state parameter.");
			  }
		
		String url = "https://www.googleapis.com/oauth2/v4/token";
		String Content_Type="application/x-www-form-urlencoded";
		HttpClient client = new DefaultHttpClient();
		HttpPost post = new HttpPost(url);

		
				
		List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
		urlParameters.add(new BasicNameValuePair("Content-Type", Content_Type));
		urlParameters.add(new BasicNameValuePair("code",code));
		urlParameters.add(new BasicNameValuePair("client_id",CLIENT_ID));
		urlParameters.add(new BasicNameValuePair("client_secret",client_secret));
		urlParameters.add(new BasicNameValuePair("redirect_uri", redirect_uri));
		urlParameters.add(new BasicNameValuePair("grant_type", "authorization_code"));

		post.setEntity(new UrlEncodedFormEntity(urlParameters));

		HttpResponse httpResponse = client.execute(post);
		System.out.println("\nSending 'POST' request to URL : " + url);
		System.out.println("Post parameters : " + post.getEntity());
		System.out.println("Response Code : " +
				httpResponse.getStatusLine().getStatusCode());

BufferedReader rd = new BufferedReader(
    new InputStreamReader(httpResponse.getEntity().getContent()));

StringBuffer result = new StringBuffer();
String line = "";
while ((line = rd.readLine()) != null) {
result.append(line);
}

System.out.println(result.toString());
Iterator<FileItem> fileItemsIterator = fileItemsList.iterator();
while(fileItemsIterator.hasNext()){
	FileItem fileItem = fileItemsIterator.next();
	System.out.println("FieldName="+fileItem.getFieldName());
	System.out.println("FileName="+fileItem.getName());
	System.out.println("ContentType="+fileItem.getContentType());
	System.out.println("Size in bytes="+fileItem.getSize());
	
	
	
}
	


	
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(!ServletFileUpload.isMultipartContent(request)){
			throw new ServletException("Content type is not multipart/form-data");
		}
		
		
		try {
			
		 fileItemsList = uploader.parseRequest(request);
			Iterator<FileItem> fileItemsIterator = fileItemsList.iterator();
			while(fileItemsIterator.hasNext()){
				FileItem fileItem = fileItemsIterator.next();
				System.out.println("FieldName="+fileItem.getFieldName());
				System.out.println("FileName="+fileItem.getName());
				System.out.println("ContentType="+fileItem.getContentType());
				System.out.println("Size in bytes="+fileItem.getSize());
				
				File file = new File(request.getServletContext().getAttribute("FILES_DIR")+File.separator+fileItem.getName());
				System.out.println("Absolute Path at server="+file.getAbsolutePath());
				
			}
		} catch (FileUploadException e) {
		System.out.println(e);
		
		} catch (Exception e) {
			System.out.println(e);
			
		}
		
		
		// Create a state token to prevent request forgery.
		  // Store it in the session for later validation.
		  String state = new BigInteger(130, new SecureRandom()).toString(32);
		  System.out.println(state);
		  request.getSession().setAttribute("state", state);
		
		
		String authenticationURI="https://accounts.google.com/o/oauth2/v2/auth?client_id="+CLIENT_ID+"&response_type=code&scope=openid%20email&redirect_uri="+
		redirect_uri+"&state="+state;
		response.sendRedirect(authenticationURI);
		
		
	}	

}